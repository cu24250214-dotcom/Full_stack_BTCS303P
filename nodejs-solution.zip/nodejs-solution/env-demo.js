// Task 12: Environment Variables
const http = require('http');

console.log('--- Task 12: Environment Variables ---\n');

// Read PORT from environment or default to 4000
const PORT = process.env.PORT || 4000;

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
        <h1>Welcome!</h1>
        <p>Server running on port: ${PORT}</p>
        <p>Environment Variables:</p>
        <ul>
            <li>PORT: ${process.env.PORT || 'not set (using default: 4000)'}</li>
            <li>NODE_ENV: ${process.env.NODE_ENV || 'not set'}</li>
        </ul>
    `);
});

server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}/`);
    console.log(`PORT environment variable: ${process.env.PORT || 'not set (using default: 4000)'}`);
    console.log('\nTo run with a custom port:');
    console.log('  Linux/Mac: PORT=5000 node env-demo.js');
    console.log('  Windows: set PORT=5000 && node env-demo.js');
    console.log('\nPress Ctrl+C to stop the server\n');
});
