// Task 3: Directory Operations
const fs = require('fs');
const path = require('path');

const uploadsDir = path.join(__dirname, 'uploads');

console.log('--- Task 3: Directory Operations ---');

// Create uploads folder
fs.mkdir(uploadsDir, { recursive: true }, (err) => {
    if (err) throw err;
    console.log('✓ Created uploads folder');

    // Create 3 empty files
    const files = ['file1.txt', 'file2.txt', 'file3.txt'];
    let filesCreated = 0;

    files.forEach((file) => {
        const filePath = path.join(uploadsDir, file);
        fs.writeFile(filePath, '', (err) => {
            if (err) throw err;
            filesCreated++;
            console.log(`✓ Created ${file}`);

            // After all files are created
            if (filesCreated === files.length) {
                // List all files
                fs.readdir(uploadsDir, (err, fileList) => {
                    if (err) throw err;
                    console.log('\n--- Files in uploads folder ---');
                    fileList.forEach((f) => console.log(`  - ${f}`));

                    // Delete one file
                    const fileToDelete = path.join(uploadsDir, 'file2.txt');
                    fs.unlink(fileToDelete, (err) => {
                        if (err) throw err;
                        console.log('\n✓ Deleted file2.txt');

                        // List remaining files
                        fs.readdir(uploadsDir, (err, fileList) => {
                            if (err) throw err;
                            console.log('\n--- Remaining files ---');
                            fileList.forEach((f) => console.log(`  - ${f}`));
                        });
                    });
                });
            }
        });
    });
});
