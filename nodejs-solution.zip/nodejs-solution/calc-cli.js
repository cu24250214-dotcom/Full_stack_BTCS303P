// Task 11: Command-Line Arguments
console.log('--- Task 11: Calculator with Command-Line Arguments ---\n');

// Get arguments from process.argv
// process.argv[0] = node executable
// process.argv[1] = script file path
// process.argv[2] = first number
// process.argv[3] = operator
// process.argv[4] = second number

const args = process.argv.slice(2);

if (args.length < 3) {
    console.log('Usage: node calc-cli.js <num1> <operator> <num2>');
    console.log('Example: node calc-cli.js 10 + 5');
    console.log('Operators: +, -, *, /');
    process.exit(1);
}

const num1 = parseFloat(args[0]);
const operator = args[1];
const num2 = parseFloat(args[2]);

if (isNaN(num1) || isNaN(num2)) {
    console.error('Error: Both arguments must be valid numbers');
    process.exit(1);
}

let result;

switch (operator) {
    case '+':
        result = num1 + num2;
        break;
    case '-':
        result = num1 - num2;
        break;
    case '*':
        result = num1 * num2;
        break;
    case '/':
        if (num2 === 0) {
            console.error('Error: Division by zero');
            process.exit(1);
        }
        result = num1 / num2;
        break;
    default:
        console.error('Error: Invalid operator. Use +, -, *, or /');
        process.exit(1);
}

console.log(`\n${num1} ${operator} ${num2} = ${result}`);
