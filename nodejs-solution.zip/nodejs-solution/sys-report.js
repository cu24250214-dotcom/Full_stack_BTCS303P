// Task 5: OS Module Report
const os = require('os');

console.log('--- Task 5: OS Module Report ---\n');

// Platform
console.log('Platform:', os.platform());

// Architecture
console.log('Architecture:', os.arch());

// CPU Information
const cpus = os.cpus();
console.log('Number of CPU Cores:', cpus.length);

// Memory Information
const totalMemory = os.totalmem();
const freeMemory = os.freemem();
const usedMemory = totalMemory - freeMemory;

console.log('Total Memory:', (totalMemory / (1024 * 1024 * 1024)).toFixed(2), 'GB');
console.log('Free Memory:', (freeMemory / (1024 * 1024 * 1024)).toFixed(2), 'GB');
console.log('Used Memory:', (usedMemory / (1024 * 1024 * 1024)).toFixed(2), 'GB');

// System Uptime in minutes
const uptimeSeconds = os.uptime();
const uptimeMinutes = Math.floor(uptimeSeconds / 60);
console.log('System Uptime:', uptimeMinutes, 'minutes');

// Hostname
console.log('Hostname:', os.hostname());

// Home directory
console.log('Home Directory:', os.homedir());
