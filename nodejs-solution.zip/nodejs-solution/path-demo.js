// Task 4: Path Module
const path = require('path');

console.log('--- Task 4: Path Module ---');

// Hardcoded file path
const filePath = '/home/user/data/report.pdf';

// Extract directory name
const dirname = path.dirname(filePath);
console.log('Directory Name:', dirname);

// Extract base name
const basename = path.basename(filePath);
console.log('Base Name:', basename);

// Extract extension
const extname = path.extname(filePath);
console.log('Extension:', extname);

// Resolve absolute path from relative path
const relativePath = './documents/notes.txt';
const absolutePath = path.resolve(relativePath);
console.log('\nRelative Path:', relativePath);
console.log('Absolute Path:', absolutePath);

// Additional path operations
console.log('\n--- Additional Path Info ---');
console.log('Join paths:', path.join('/home', 'user', 'documents', 'file.txt'));
console.log('Normalize:', path.normalize('/home//user///documents/'));
