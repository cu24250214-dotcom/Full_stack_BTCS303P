// Task 7: HTTP Server with Manual Routing
const http = require('http');
const url = require('url');

// Sample students data
const students = [
    { id: 1, name: 'Raj Kumar', rollNo: 'BT21CSE001' },
    { id: 2, name: 'Priya Singh', rollNo: 'BT21CSE002' },
    { id: 3, name: 'Aditya Patel', rollNo: 'BT21CSE003' }
];

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const query = parsedUrl.query;

    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);

    // Route: GET /
    if (pathname === '/' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end('<h1>Welcome to Node.js HTTP Server</h1><p>Use routes like /students, /students/1, /search?keyword=test</p>');
    }
    // Route: GET /students
    else if (pathname === '/students' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(students));
    }
    // Route: GET /students/:id
    else if (pathname.startsWith('/students/') && req.method === 'GET') {
        const id = parseInt(pathname.split('/')[2]);
        const student = students.find(s => s.id === id);
        
        if (student) {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify(student));
        } else {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Student not found' }));
        }
    }
    // Route: GET /search
    else if (pathname === '/search' && req.method === 'GET') {
        const keyword = query.keyword || 'none';
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ keyword: keyword, message: `Search results for: ${keyword}` }));
    }
    // Default: 404
    else {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 - Page Not Found</h1><p>The requested route does not exist.</p>');
    }
});

const PORT = 3000;
server.listen(PORT, () => {
    console.log(`\n--- Task 7: HTTP Server with Manual Routing ---`);
    console.log(`Server running at http://localhost:${PORT}/`);
    console.log('\nAvailable Routes:');
    console.log('  GET http://localhost:3000/');
    console.log('  GET http://localhost:3000/students');
    console.log('  GET http://localhost:3000/students/1');
    console.log('  GET http://localhost:3000/search?keyword=node');
    console.log('\nPress Ctrl+C to stop the server\n');
});
