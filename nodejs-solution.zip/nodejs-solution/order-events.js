// Task 6: Events Module - Custom EventEmitter
const EventEmitter = require('events');

console.log('--- Task 6: Custom EventEmitter for Orders ---\n');

// Create custom EventEmitter for orders
class OrderManager extends EventEmitter {}

const orderManager = new OrderManager();

// Listen to orderPlaced event
orderManager.on('orderPlaced', (order) => {
    console.log('========== ORDER RECEIPT ==========');
    console.log('Order ID:', order.id);
    console.log('Item:', order.item);
    console.log('Amount: $' + order.amount);
    console.log('==================================\n');
});

// Emit orderPlaced event 3 times with different orders
const orders = [
    { id: 101, item: 'Laptop', amount: 999.99 },
    { id: 102, item: 'Mouse', amount: 29.99 },
    { id: 103, item: 'Keyboard', amount: 79.99 }
];

orders.forEach((order) => {
    orderManager.emit('orderPlaced', order);
});

console.log('All orders processed successfully!');
