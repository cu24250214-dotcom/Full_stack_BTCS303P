// Task 1: Custom Modules - sum.js
// Function to calculate sum of two numbers
function calculateSum(a, b) {
    return a + b;
}

module.exports = calculateSum;
