// Task 1: Custom Modules - app1.js
// Import custom modules
const calculateSum = require('./sum.js');
const checkEvenOdd = require('./even-odd.js');

// Test calculateSum function
console.log('--- Task 1: Custom Modules ---');
console.log('Sum of 10 and 20:', calculateSum(10, 20));
console.log('Sum of 15 and 25:', calculateSum(15, 25));

// Test checkEvenOdd function
console.log('\nChecking Even/Odd:');
console.log(checkEvenOdd(15));
console.log(checkEvenOdd(20));
console.log(checkEvenOdd(33));
