// Task 10: npm and External Package (nanoid)
const { nanoid } = require('nanoid');

console.log('--- Task 10: Generating Unique IDs with nanoid ---\n');

console.log('Generated 5 unique IDs:\n');
for (let i = 1; i <= 5; i++) {
    const uniqueId = nanoid();
    console.log(`ID ${i}: ${uniqueId}`);
}

console.log('\n--- Custom nanoid examples ---');
console.log('Shorter ID (8 chars):', nanoid(8));
console.log('Longer ID (20 chars):', nanoid(20));
console.log('Custom alphabet:', nanoid(10, '0123456789ABCDEF'));
