// Task 9: Reading Large File with Streams
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'large-file.txt');

console.log('--- Task 9: File Streams ---\n');

// Step 1: Create a text file with at least 50 lines
console.log('Creating large-file.txt with 100 lines...');
let content = '';
for (let i = 1; i <= 100; i++) {
    content += `Line ${i}: This is sample content for stream reading demonstration.\n`;
}

fs.writeFile(filePath, content, (err) => {
    if (err) throw err;
    console.log('✓ File created successfully\n');

    // Step 2: Read the file using streams
    console.log('Reading file using fs.createReadStream...\n');
    
    const readStream = fs.createReadStream(filePath, { encoding: 'utf8' });
    let chunkCount = 0;
    let totalBytes = 0;

    readStream.on('data', (chunk) => {
        chunkCount++;
        totalBytes += chunk.length;
        console.log(`Chunk ${chunkCount}: ${chunk.length} bytes received`);
    });

    readStream.on('end', () => {
        console.log(`\n✓ Stream reading complete!`);
        console.log(`Total chunks: ${chunkCount}`);
        console.log(`Total bytes: ${totalBytes}`);
    });

    readStream.on('error', (err) => {
        console.error('Error reading file:', err);
    });
});
