// Task 8: Query String Parsing
const http = require('http');
const url = require('url');

const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const query = parsedUrl.query;

    console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`);

    if (pathname === '/search' && req.method === 'GET') {
        const keyword = query.keyword || 'not specified';
        const category = query.category || 'all';
        
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            search: {
                keyword: keyword,
                category: category,
                message: `Search results for keyword: "${keyword}" in category: "${category}"`
            }
        }));
    }
    else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(`
            <h1>Task 8: Query String Parsing Demo</h1>
            <p>Try these URLs:</p>
            <ul>
                <li><a href="/search?keyword=node">http://localhost:3001/search?keyword=node</a></li>
                <li><a href="/search?keyword=javascript&category=web">http://localhost:3001/search?keyword=javascript&category=web</a></li>
                <li><a href="/search">http://localhost:3001/search (no params)</a></li>
            </ul>
        `);
    }
});

const PORT = 3001;
server.listen(PORT, () => {
    console.log(`\n--- Task 8: Query String Parsing ---`);
    console.log(`Server running at http://localhost:${PORT}/`);
    console.log('Try: http://localhost:3001/search?keyword=node');
    console.log('Try: http://localhost:3001/search?keyword=test&category=web\n');
});
