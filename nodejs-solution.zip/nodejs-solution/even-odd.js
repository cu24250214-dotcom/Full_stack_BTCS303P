// Task 1: Custom Modules - even-odd.js
// Function to check if a number is even or odd
function checkEvenOdd(num) {
    if (num % 2 === 0) {
        return `${num} is Even`;
    } else {
        return `${num} is Odd`;
    }
}

module.exports = checkEvenOdd;
