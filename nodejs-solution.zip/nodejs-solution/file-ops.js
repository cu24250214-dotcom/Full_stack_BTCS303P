// Task 2: File System - CRUD on a Text File
const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'student.txt');
const newFilePath = path.join(__dirname, 'profile.txt');

console.log('--- Task 2: File System CRUD ---');

// Create and write to student.txt
fs.writeFile(filePath, 'Name: Raj Kumar\nRoll Number: BT21CSE001\n', (err) => {
    if (err) throw err;
    console.log('✓ Created student.txt and wrote name and roll number');

    // Append course name
    fs.appendFile(filePath, 'Course: Full Stack Web Development\n', (err) => {
        if (err) throw err;
        console.log('✓ Appended course name');

        // Read and print full content
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) throw err;
            console.log('\n--- File Content ---');
            console.log(data);
            console.log('--- End of File ---\n');

            // Rename file
            fs.rename(filePath, newFilePath, (err) => {
                if (err) throw err;
                console.log('✓ Renamed student.txt to profile.txt');
            });
        });
    });
});
